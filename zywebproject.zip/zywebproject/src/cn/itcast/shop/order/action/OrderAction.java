package cn.itcast.shop.order.action;



import java.io.IOException;
import java.util.Date;

import org.apache.struts2.ServletActionContext;

import cn.itcast.shop.cart.domain.Cart;
import cn.itcast.shop.cart.domain.CartItem;
import cn.itcast.shop.order.domain.Order;
import cn.itcast.shop.order.domain.OrderItem;
import cn.itcast.shop.order.service.OrderService;
import cn.itcast.shop.user.domain.User;
import cn.itcast.shop.utils.PageBean;
import cn.itcast.shop.utils.PaymentUtil;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class OrderAction extends ActionSupport implements ModelDriven<Order>{
    Order order=new Order();
	public Order getModel() {
		return order;
	}
    private OrderService orderService;
	public void setOrderService(OrderService orderService) {
		this.orderService = orderService;
	}
	private Integer page;
	
    public void setPage(Integer page) {
		this.page = page;
	}
    private String pd_FrpId;
    
	public void setPd_FrpId(String pdFrpId) {
		pd_FrpId = pdFrpId;
	}
	 public String check(){
	    	Order currOrder =orderService.findByOid(order.getOid());
	    	currOrder.setAddr(order.getAddr());
	    	currOrder.setName(order.getName());
	    	currOrder.setPhone(order.getPhone());
	    	orderService.update(currOrder);
	    	String p0_Cmd="buy";//涓氬姟绫诲瀷
	    	String p1_MerId="10001126856";//鍟嗘埛鐨勭紪鍙�
	    	String p2_Order=order.getOid().toString();//璁㈠崟鍙�
	    	String p3_Amt="0.01";//閲戦
	    	String p4_Cur="CNY";//甯佺
	    	String p5_Pid="";//鍟嗗搧鍚嶇О
	    	String p6_Pcat="";//鍟嗗搧绉嶇被
	    	String p7_Pdesc="";//鍟嗗搧鎻忚堪
	    	String p8_Url="http://localhost:8080/zywebproject/order_callBack.action";//
	    	String p9_SAF="";
	    	String pa_MP="";
	    	String pd_FrpId=this.pd_FrpId;
	    	String pr_NeedResponse="1";//搴旂瓟鏈哄埗
	    	String hmac=PaymentUtil.buildHmac(p0_Cmd, p1_MerId, p2_Order, p3_Amt, p4_Cur, p5_Pid, p6_Pcat, p7_Pdesc, p8_Url, p9_SAF, pa_MP, pd_FrpId, pr_NeedResponse, "69cl522AV6q613Ii4W6u8K6XuW8vM1N6bFgyv769220IuYe9u37N4y7rI4Pl");
	    	StringBuffer sb=new StringBuffer("https://www.yeepay.com/app-merchant-proxy/node?");
	    	sb.append("p0_Cmd=").append(p0_Cmd).append("&").
	    	append("p1_MerId=").append(p1_MerId).append("&").
	    	append("p2_Order=").append(p2_Order).append("&").
	    	append("p3_Amt=").append(p3_Amt).append("&").
	    	append("p4_Cur=").append(p4_Cur).append("&").
	    	append("p5_Pid=").append(p5_Pid).append("&").
	    	append("p6_Pcat=").append(p6_Pcat).append("&").
	    	append("p7_Pdesc=").append(p7_Pdesc).append("&").
	    	append("p8_Url=").append(p8_Url).append("&").
	    	append("p9_SAF=").append(p9_SAF).append("&").
	    	append("pa_MP=").append(pa_MP).append("&").
	    	append("pd_FrpId=").append(pd_FrpId).append("&").
	    	append("pr_NeedResponse=").append(pr_NeedResponse).append("&").
	    	append("hmac=").append(hmac);
	    	System.out.println(sb.toString());
	    	try {
				ServletActionContext.getResponse().sendRedirect(sb.toString());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	return NONE;
	    }
	public String save(){
    	order.setDatetime(new Date());
    	order.setState(1);
    	Cart cart=(Cart) ServletActionContext.getRequest().getSession().getAttribute("cart");  
    	if(cart==null){
    		this.addActionError("浜诧紝浣犺繕娌℃湁璐墿锛岃鍏堝幓璐墿");
    		return "msg";
    	}
    	order.setTotal(cart.getTotal());
    	for(CartItem cartItem :cart.getCartItems()){
    		OrderItem orderItem=new OrderItem();
    		orderItem.setCount(cartItem.getCount());
    		orderItem.setProduct(cartItem.getProduct());
    		orderItem.setSubtotal(cartItem.getSubtotal());
    		order.getOrderItems().add(orderItem);
    	}
    	User exituser=(User) ServletActionContext.getRequest().getSession().getAttribute("exitUser");
    	if(exituser==null){
    		this.addActionError("浜诧紝浣犺繕娌＄櫥褰曪紝璇峰厛鍘荤櫥褰");
    		return "login";
    	}
    	order.setUser(exituser);
    	orderService.save(order);
    	cart.clearCartItem();
    	return "save";
    }
    public String findByUid(){
    	User user=(User) ServletActionContext.getRequest().getSession().getAttribute("exitUser");
    	PageBean<Order> pageBean=orderService.findByUid(user.getUid(),page);
    	ActionContext.getContext().getValueStack().set("pageBean", pageBean);
    	System.out.println(pageBean);
    	return "findByUid";
    }
    public String findByOid(){
    	order=orderService.findByOid(order.getOid());
    	return "findByOid";
    } 
   
}
