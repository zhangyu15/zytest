package cn.itcast.shop.order.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import cn.itcast.shop.order.domain.Order;
import cn.itcast.shop.utils.PageHibernateCallback;

public class OrderDao extends HibernateDaoSupport{
	public void save(Order order) {
		this.getHibernateTemplate().save(order);

	}

	public Integer findByCountUid(Integer uid) {
	    String hql="select count(*) from Order o where o.user.uid=?";
	    List<Long> list=(List<Long>) this.getHibernateTemplate().find(hql, uid);
		if(list!=null &&list.size()>0){
			return list.get(0).intValue();
		}
	    return null;
	}

	public List<Order> findByPageUid(Integer uid, Integer begin, Integer limit) {
		String hql=" from Order o where o.user.uid=? order by ordertime desc";
		List<Order> list=this.getHibernateTemplate().execute(new PageHibernateCallback<Order>(hql, new Object[]{uid}, begin, limit));
		if(list!=null &&list.size()>0){
			return list;
		}
		return null;
	}

	public Order findByOid(Integer oid) {
		return this.getHibernateTemplate().get(Order.class, oid);
	}

	public void update(Order currOrder) {
		this.getHibernateTemplate().update(currOrder);
	}
	
}
