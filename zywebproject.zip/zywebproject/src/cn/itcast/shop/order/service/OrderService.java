package cn.itcast.shop.order.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import cn.itcast.shop.order.dao.OrderDao;
import cn.itcast.shop.order.domain.Order;
import cn.itcast.shop.utils.PageBean;

@Transactional
public class OrderService {
	private OrderDao orderDao;

	public void setOrderDao(OrderDao orderDao) {
		this.orderDao = orderDao;
	}

	public void save(Order order) {
		 orderDao.save(order);
	}

	public PageBean<Order> findByUid(Integer uid, Integer page) {
		PageBean<Order> pageBean=new PageBean<Order>();
		//设置当前页数
		pageBean.setPage(page);
		//每页显示的记录数
		Integer limit=5;
		//总记录数
		Integer totalCount=null;
		totalCount=orderDao.findByCountUid(uid);
		//总页数
		Integer totalpage=null;
		if(totalCount%2==0){
			totalpage=totalCount/limit;
		}else{
			totalpage=totalCount/limit+1;
		}
		//设置总页数
		pageBean.setTotalpage(totalpage);
		//每页显示的集合
		Integer begin=(page-1)*limit;
		List<Order> list=orderDao.findByPageUid(uid,begin,limit);
		pageBean.setList(list);
		return pageBean;
	}

	public Order findByOid(Integer oid) {
		return orderDao.findByOid(oid);
	}

	public void update(Order currOrder) {
		orderDao.update(currOrder);
	}
	
}
