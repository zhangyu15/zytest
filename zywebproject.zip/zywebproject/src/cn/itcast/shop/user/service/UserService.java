package cn.itcast.shop.user.service;

import org.springframework.transaction.annotation.Transactional;

import cn.itcast.shop.user.dao.UserDao;
import cn.itcast.shop.user.domain.User;
import cn.itcast.shop.utils.MailUtils;
import cn.itcast.shop.utils.UUIDUtils;

//开启事务的注解，这个很重要
@Transactional
public class UserService {
	private UserDao userDao;

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}
	public User findByName(String username){
		return userDao.findByName(username);
	}
	public void save(User user) {
		user.setState(0);
		user.setCode(UUIDUtils.getUUID()+UUIDUtils.getUUID());
		userDao.save(user);
		//邮箱激活
		MailUtils.sendMail(user.getEmail(), user.getCode());
	}
	public User findByCode(String code) {
		
		return userDao.findByCode(code);
	}
	public void update(User exitUser) {
		userDao.update(exitUser);
	}
	public User login(User user) {
		return userDao.login(user);
	}
	
}
