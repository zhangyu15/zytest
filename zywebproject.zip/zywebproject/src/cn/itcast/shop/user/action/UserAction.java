package cn.itcast.shop.user.action;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import cn.itcast.shop.user.domain.User;
import cn.itcast.shop.user.service.UserService;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class UserAction extends ActionSupport implements ModelDriven<User>{
	private User user=new User();
	public User getModel() {
		return user;
	}
	//灞炴�椹卞姩
	private String checkcode;
	public void setCheckcode(String checkcode) {
		this.checkcode = checkcode;
	}
	/**
	 * 璺宠浆鐨勬敞鍐岄〉闈�
	 */
	public String register() throws Exception {
		return "register";
	}
	//userservice鐨勬敞鍏�
	private UserService userService;
	public void setUserService(UserService userService) {
		this.userService = userService;
	}
	
	/**
	 * 浣跨敤ajax杩涜鐢ㄦ埛鍚嶇殑鏍￠獙
	 * @throws IOException 
	 */
	public String findByName() throws IOException{
		User u=userService.findByName(user.getUsername());
		HttpServletResponse response=ServletActionContext.getResponse();
		//璁剧疆瀛楃闆嗙殑缂栫爜
		response.setContentType("text/html;charset=UTF-8");
		if(u!=null){
			response.getWriter().println("<font color='red'>用户名已经存在</font>");
		}else{
			response.getWriter().println("<font color='green'>该用户名可用</font>");
		}
		return NONE;
	}
	/*
	 * 注册
	 */
	public String regist(){
		String code=(String) ServletActionContext.getRequest().getSession().getAttribute("checkImg");
		System.out.println(code);
		if(!checkcode.equalsIgnoreCase(code)){
			this.addActionError("验证码不正确");
			return "register";
		}
		userService.save(user);
		System.out.println(user.getPhone());
		this.addActionMessage("<h1>注册成功请到邮箱激活</h1>");
		return "msg";
	}
	/*
	 * 邮箱激活
	 */
	public String active(){
		User exitUser=userService.findByCode(user.getCode());
//		System.out.println(exitUser);
//		System.out.println(user.getCode());
//		System.out.println(user.getPhone());
		if(exitUser==null){
			this.addActionMessage("<h1>该用户未注册成功</h1>");
			return "msg";
		}else{
			exitUser.setState(1);
			exitUser.setCode(null);
			userService.update(exitUser);
			this.addActionMessage("<h1>激活成功请登录</h1>");
			return "msg";
		}
	}
	/*
	 * 璺宠浆鐨勭櫥褰曢〉闈�
	 */
	public String loginPage(){
		return "loginPage";
	}
	/*
	 * 瀹炵幇鐧诲綍鍔熻兘
	 */
	public String login(){
		String code=(String) ServletActionContext.getRequest().getSession().getAttribute("checkImg");
		if(!checkcode.equalsIgnoreCase(code)){
			this.addActionError("验证码不正确");
			return "login";
		}
		User exitUser=userService.login(user);
		//System.out.println(exitUser+"pppppppp");
		if(exitUser==null){
			this.addActionError("用户名或者密码错误");
			return "login";
		}else{
			//鐢ㄤ簬鍥炴樉
			ServletActionContext.getRequest().getSession().setAttribute("exitUser", exitUser);
			System.out.println(ServletActionContext.getRequest().getSession().getAttribute("exitUser"));
		    return "loginsuccess";
		}
	}
	/*
	 * 閫�嚭
	 */
	public String quit(){
		//娑堥櫎session
		ServletActionContext.getRequest().getSession().invalidate();
		return "quit";
	}
	
}
