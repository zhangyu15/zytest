package cn.itcast.shop.user.action;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.Random;

import javax.imageio.ImageIO;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.sun.org.apache.commons.digester.rss.Image;

public class CheckImgAction extends ActionSupport{
//	private int width=70;
//	private int heigth=35;
//	private Random r=new Random();
//	private String [] fontNames={"宋体","黑体","楷体","微软雅黑","幼圆"};
//	private String codes="2345679abcdefghijkmnprstuvwxyzABCDEFGHIJKLMNPQRSTUVWXYZ";
//	private Color bgColor=new Color(255,255,255);
//	private String text;
//	//随机获取颜色
//	private Color randomColor(){
//		int red=r.nextInt(150);
//		int green=r.nextInt(150);
//		int blue=r.nextInt(150);
//		return new Color(red,green,blue);
//	}
//	//随机获取字体
//	private Font randomFont(){
//		int index=r.nextInt(fontNames.length);
//		String fontName=fontNames[index];
//		int style=r.nextInt(4);//生成字体的样式，0表示无样式，1表示粗体，2表示斜体，3表示粗体+斜体
//		int size=r.nextInt(5)+24;//表示字体
//		return new Font(fontName,style,size);
//	}
//	//生成干扰线
//	private void drawLine(BufferedImage image){
//		int num=3;//表示生成三天干扰线
//		Graphics2D g2=(Graphics2D) image.getGraphics();
//		for (int i = 0; i < num; i++) {
//			int x1=r.nextInt(width);
//			int y1=r.nextInt(heigth);
//			int x2=r.nextInt(width);
//			int y2=r.nextInt(heigth);
//			g2.setStroke(new BasicStroke(1.5F));
//			g2.setColor(Color.BLUE);
//			g2.drawLine(x1, y1, x2, y2);
//		}		
//	}
//	//随机生成字符
//	private char randomChar(){
//		int index=r.nextInt(codes.length());
//		return codes.charAt(index);
//	}
//	//生成图片缓冲区
//	private BufferedImage createImage(){
//		BufferedImage image=new BufferedImage(width, heigth,BufferedImage.TYPE_INT_RGB);
//		Graphics2D g2=(Graphics2D) image.getGraphics();
//		g2.setColor(this.bgColor);
//		g2.fillRect(0, 0, width, heigth);
//		return image;
//	}
//	//得到图片
//	public BufferedImage getImage(){
//		BufferedImage image=createImage();
//		Graphics2D g2=(Graphics2D) image.getGraphics();
//		StringBuilder sb=new StringBuilder();
//		for(int i=0;i<4;i++){
//			String s=randomChar()+"";
//			sb.append(s);
//			float x=i*1.0F*width/4;
//			g2.setFont(randomFont());
//			g2.setColor(randomColor());
//			g2.drawString(s,x,heigth-5);
//		}
//		this.text=sb.toString();
//		drawLine(image);
//		return image;
//	}
	
	//图片输出
    public String execute() throws Exception {
    	 int width=120;
    	 int height=30;
    	 Random r=new Random();
    	 String [] fontNames={"宋体","黑体","楷体","微软雅黑","幼圆"};
    	 String codes="2345679abcdefghijkmnprstuvwxyzABCDEFGHIJKLMNPQRSTUVWXYZ";
    	 Color bgColor=new Color(255,255,255);
    	BufferedImage bimage=new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
    	Graphics2D g=(Graphics2D) bimage.getGraphics();
    	g.setColor(bgColor);
    	g.fillRect(0, 0, width, height);
    	//字体的颜色
    	int red=r.nextInt(150);
		int green=r.nextInt(150);
		int blue=r.nextInt(150);
		//字体的字样
		String fontName=fontNames[r.nextInt(fontNames.length)];
		int style=r.nextInt(4);//生成字体的样式，0表示无样式，1表示粗体，2表示斜体，3表示粗体+斜体
		int size=r.nextInt(5)+24;//表示字体
		//生成干扰线3条
		int num=3;
		Graphics2D g2=(Graphics2D) bimage.getGraphics();
		for (int i = 0; i < num; i++) {
			int x1=r.nextInt(width);
			int y1=r.nextInt(height);
			int x2=r.nextInt(width);
			int y2=r.nextInt(height);
			g2.setStroke(new BasicStroke(1.5F));
			g2.setColor(Color.BLUE);
			g2.drawLine(x1, y1, x2, y2);
		}		
    	//生成图片
		StringBuilder sb=new StringBuilder();
		for(int i=0;i<4;i++){
			String s=codes.charAt(r.nextInt(codes.length()))+"";
			sb.append(s.trim());
			float x=i*1.0F*width/4;
			g2.setFont(new Font(fontName, style, size));
			g2.setColor(new Color(red, green, blue));
			g2.drawString(s,x,height-5);
		}
		
    	
    	//将生成的字符存入session中
		ServletActionContext.getRequest().getSession().setAttribute("checkImg", sb.toString());
    	//将验证输出
    	ImageIO.write(bimage, "jpg", ServletActionContext.getResponse().getOutputStream());
    	return NONE;
    }

	
}
