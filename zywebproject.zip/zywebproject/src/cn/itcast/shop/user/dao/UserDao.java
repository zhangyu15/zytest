package cn.itcast.shop.user.dao;

import java.util.List;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import cn.itcast.shop.user.domain.User;

public class UserDao extends HibernateDaoSupport{
	public User findByName(String username){
		String hql="from User where username = ?";
		List<User> list=(List<User>) this.getHibernateTemplate().find(hql, username);
	    if(list!=null && list.size()>0){
	    	return list.get(0);
	    }else
	    	return null;
	}

	public void save(User user) {
		String md5Digest=DigestUtils.md5Hex(user.getPassword());
	    user.setPassword(md5Digest);
		this.getHibernateTemplate().save(user);
		
	}

	public User findByCode(String code) {
		String hql="from User where code=?";
		List<User> list=(List<User>) this.getHibernateTemplate().find(hql, code);
		//System.out.println("到的"+list);
		if(list!=null && list.size()>0){
			return list.get(0);
		}else{
			return null;
		}
	}
    /*
     * 修改用户状态
     */
	public void update(User exitUser) {
		this.getHibernateTemplate().update(exitUser);
	}

	public User login(User user) {
		String hql="from User where username = ? and password = ? and state = ?";
		//此处注意先把密码转换为MD5，再与数据库进行比较
		List<User> list=(List<User>) this.getHibernateTemplate().find(hql, user.getUsername(),DigestUtils.md5Hex(user.getPassword()),1);
		if(list!=null && list.size()>0){
			return list.get(0);
		}else
			return null;
	}
}
