package cn.itcast.shop.index.action;

import java.util.List;

import org.apache.struts2.ServletActionContext;

import cn.itcast.shop.category.domain.Category;
import cn.itcast.shop.category.service.CategoryService;
import cn.itcast.shop.product.domain.Product;
import cn.itcast.shop.product.service.ProductService;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class IndexAction extends ActionSupport{
	//categoryService的注入
	private CategoryService categoryService;

	public void setCategoryService(CategoryService categoryService) {
		this.categoryService = categoryService;
	}
	//productService的注入
	private ProductService productService;
	
	public void setProductService(ProductService productService) {
		this.productService = productService;
	}

	public String execute() throws Exception  {
		//查询所有的一级目录
		List<Category> clist=categoryService.findAll();
		//把数据存入session
		ServletActionContext.getContext().getSession().put("clist", clist);
		//查询热门商品
		List<Product> plist=productService.findHot();
		//把数据存入值栈中
		ActionContext.getContext().getValueStack().set("plist", plist);
		//查询最新的商品
		List<Product> nlist=productService.findNew();
		//将数据存入值栈中
		ActionContext.getContext().getValueStack().set("nlist", nlist);
		return "index";
	}
}
