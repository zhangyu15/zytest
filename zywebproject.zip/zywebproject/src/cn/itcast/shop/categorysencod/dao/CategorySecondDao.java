package cn.itcast.shop.categorysencod.dao;

public class CategorySecondDao {

}
