package cn.itcast.shop.product.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import cn.itcast.shop.product.dao.ProductDao;
import cn.itcast.shop.product.domain.Product;
import cn.itcast.shop.utils.PageBean;
@Transactional//开启注解
public class ProductService {
	//注入productDao
	private ProductDao productDao;

	public void setProductDao(ProductDao productDao) {
		this.productDao = productDao;
	}

	public List<Product> findHot() {
		return productDao.findHot();
	}

	public List<Product> findNew() {
		return productDao.findNew();
	}

	public Product findByPid(Integer pid) {
		return productDao.findByPid(pid);
	}

	public PageBean<Product> findByPageId(Integer cid, int page) {
		PageBean<Product> pageBean=new PageBean<Product>();
		pageBean.setPage(page);//当前页数
		int limit=8;
		pageBean.setLimit(limit);
		//总记录数
		int totalCount=0;
		totalCount=productDao.findByCountCid(cid);
		pageBean.setTotalCount(totalCount);
		int totalPage=0;//设置总页数
		totalPage=(int) Math.ceil(totalCount/limit);
		pageBean.setTotalpage(totalPage);
		int begin=(page-1)*limit;
		List<Product> list=productDao.findByPageCid(cid,begin,limit);
		pageBean.setList(list);
		return pageBean;
	}

	public PageBean<Product> findByCsid(Integer csid, int page) {
		PageBean<Product> pageBean=new PageBean<Product>();
		pageBean.setPage(page);//当前页数
		int limit=8;
		pageBean.setLimit(limit);
		//总记录数
		int totalCount=0;
		totalCount=productDao.findByCountCsid(csid);
		pageBean.setTotalCount(totalCount);
		int totalPage=0;//设置总页数
		totalPage=(int) Math.ceil(totalCount/limit);
		pageBean.setTotalpage(totalPage);
		int begin=(page-1)*limit;
		List<Product> list=productDao.findByPageCsid(csid,begin,limit);
		pageBean.setList(list);
		return pageBean;
	}
	
}
