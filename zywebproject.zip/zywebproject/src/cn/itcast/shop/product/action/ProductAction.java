package cn.itcast.shop.product.action;

import java.util.List;

import cn.itcast.shop.product.domain.Product;
import cn.itcast.shop.product.service.ProductService;
import cn.itcast.shop.utils.PageBean;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class ProductAction extends ActionSupport implements ModelDriven<Product>{
	//模型驱动
	private Product product=new Product();
	//注入productService
	private ProductService productService;
    
	public void setProductService(ProductService productService) {
		this.productService = productService;
	}

	public Product getModel() {
		return product;
	}
	public String findByPid(){
		product=productService.findByPid(product.getPid());
		return "findByPid";
	}
	//属性驱动
	private int page;//当前页数
	private Integer csid;
	
	public void setCsid(Integer csid) {
		this.csid = csid;
	}

	public void setPage(int page) {
		this.page = page;
	}
    private Integer cid;
    
	public Integer getCid() {
		return cid;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}

	//按照id查询
	public String findByCid(){
		PageBean<Product> list=productService.findByPageId(cid,page);
		//存入值栈
		//System.out.println(list.getList().get(0));
		ActionContext.getContext().getValueStack().set("pageBean", list);
		return "findByCid";
	}
	//按照csid二级查询
	public String findByCsid(){
		PageBean<Product> pageBean=productService.findByCsid(csid,page);
		//将值存入值栈
		ActionContext.getContext().getValueStack().set("pageBean", pageBean);
		return "findByCsid";
	}

}
