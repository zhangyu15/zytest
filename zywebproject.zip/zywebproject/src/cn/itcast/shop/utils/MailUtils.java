package cn.itcast.shop.utils;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;


public class MailUtils {
	public static void sendMail(String to,String code){
		
		//获得连接
		Properties props=new Properties();
		props.setProperty("mail.transport.protocol", "smtp");
		props.setProperty("mail.smtp.auth", "true");
		props.setProperty("mail.host", "smtp.126.com");
		
		Session session=Session.getInstance(props, new Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				//发邮件的信箱
				return new PasswordAuthentication("zy_wydyx","zhangyu535300");
			}		
		});
		//创建邮件对象
		MimeMessage message=new MimeMessage(session);
		try {
			//发件人的邮箱服务器的地址
			message.setFrom(new InternetAddress("zy_wydyx@126.com"));
			message.setRecipient(RecipientType.TO, new InternetAddress(to));
			//设置标题
			message.setSubject("来自雨的购物商城");
			//设置邮件内容
			message.setContent("<h1>来自雨的购物商城的激活邮件，请点击此处完成激活</h1><h3><a href='http://localhost:8080/zywebproject/user_active.action?code="+code+"'>http://localhost:8080/zywebproject/user_active.action?code="+code+"</a></h3>", "text/html;charset=UTF-8");
			//发送邮件
			Transport.send(message);
		} catch (AddressException e) {
			e.printStackTrace();
		} catch (MessagingException e) {
			e.printStackTrace();
		}
		
	}

	public static void main(String[] args) {
		sendMail("13978846354@163.com", "111111111111111111");
	}
}
