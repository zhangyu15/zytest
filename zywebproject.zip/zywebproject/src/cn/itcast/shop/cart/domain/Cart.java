package cn.itcast.shop.cart.domain;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

public class Cart {
	private Map<Integer, CartItem> map=new LinkedHashMap<Integer, CartItem>();
	private double total;
	private Collection<CartItem> cartItems;
	public double getTotal() {
		return total;
	}
	public Collection<CartItem> getCartItems(){
		cartItems=map.values();
		return cartItems;
	}

	// 添加
	public void addCartItem(CartItem cartItem) {
		//获取pid
		Integer pid=cartItem.getProduct().getPid();
		if(map.containsKey(pid)){
			CartItem _cartItem=map.get(pid);//原来的购物项目
			_cartItem.setCount(_cartItem.getCount()+cartItem.getCount());
		}else{
			map.put(pid, cartItem);
		}
		total+=cartItem.getSubtotal();
		System.out.println(total);
	}

	// 删除
	public void removeCartItem(Integer pid) {
        CartItem cartItem=map.remove(pid);
        total-=cartItem.getSubtotal();
	}

	// 清空
	public void clearCartItem() {
		map.clear();
		total=0;
	}
}
