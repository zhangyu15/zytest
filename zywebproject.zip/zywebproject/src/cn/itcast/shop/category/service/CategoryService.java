package cn.itcast.shop.category.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import cn.itcast.shop.category.dao.CategoryDao;
import cn.itcast.shop.category.domain.Category;

@Transactional//开启事务的注解，这个很重要，否则插入删除会出问题
public class CategoryService {
	//categoryDao的注入
	private CategoryDao categoryDao;

	public void setCategoryDao(CategoryDao categoryDao) {
		this.categoryDao = categoryDao;
	}

	public List<Category> findAll() {
		
		return categoryDao.findAll();
	}

	
}
